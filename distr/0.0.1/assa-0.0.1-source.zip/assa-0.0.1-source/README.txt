
# $Id: README.txt 2557 2016-04-21 12:55:03Z antonov $


################
# Introduction #
################
ASSA is a pipeline for large scale RNA-RNA interaction prediction that utilizes thermodymanics tools from the RNAstructure package.


#################
# Prerequisites #
#################
To use ASSA, you will need to install:
* blastn: https://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE_TYPE=BlastDocs&DOC_TYPE=Download
* Fold and bifold tools from the RNAstructure package: http://rna.urmc.rochester.edu/Overview/index.html
     - Don't forget to set the DATAPATH environment variable: http://rna.urmc.rochester.edu/Text/Thermodynamics.html
* R: https://www.r-project.org/
* Statistics::R Perl module
* You will also need to have Perl intalled


##################################
# ASSA Installation Instructions #
##################################
1) Unpack and copy files:
   unzip assa-0.0.1-source.zip
   cd assa-0.0.1-source
   chmod a+x ASSA/assa.pl
   mv -v ASSA ~/bin

2) Configure environment variables -- add the fillowing lines to your ~/.bash_profile and type "source ~/.bash_profile":
   export PATH=$PATH:$HOME/bin/ASSA
   export PERL5LIB=$PERL5LIB:$HOME/bin/ASSA

3) Test run:
   - To make sure that RNAstrucrure tools have been installed properly you can type "Fold _7SL.fna _7SL.ct"
   - To test that ASSA is installed properly just type 'assa.pl' and you will see version and usage message
   - To run ASSA on the sample sequences using 4 CPUs you can type: "assa.pl --num_threads 4 _7SL.fna _TP53.fna"


##############################
# Enabling more ASSA options #
##############################
You may want to install the following items to enable additional ASSA options:

* To enable HTML-based ouput in ASSA (--html option) you will need the following Perl modules:
    - HTML::Template
    - Bio::Perl
    - Bio::Graphics

* To enable automatic masking of Alu repeas (--filter_alu option) you will need to install:
    - RepeatMasker: http://www.repeatmasker.org/RMDownload.html


###################
# IMPORTANT NOTES #
###################
The transcript sequences you provide as input to assa.pl must consist of ACGT symbols ONLY.
No other letters (such as N) are allowed.


###
Ivan Antonov (ivan.antonov@gatech.edu)
Sep 7, 2016

